script.service.checkpreviousepisode
===================================

xbmc service script addon checkpreviousepisode